@echo off
setlocal enabledelayedexpansion
title AnimePlayer + AnimeLibrary build
cd /d "%~dp0"

rem ======================= OPTIONS =======================
rem CONFIG_MODE: APPDATA  = install the config to %%APPDATA%%\mpv (what the mpv-anime-build readme says; existing folder is backed up first)
rem              PORTABLE = put it in dist\portable_config next to mpvnet.exe
set CONFIG_MODE=APPDATA
rem POTPLAYER_WINS: 0 = anime-build keys win on a clash, 1 = PotPlayer keys win (see dist key-conflicts.txt in the config folder)
set POTPLAYER_WINS=0
rem HWDEC: replaces the anime build's hwdec=nvdec,vulkan,auto (RX 580 = no NVDEC). Use auto-safe / d3d11va / empty to keep the build's own.
set HWDEC=d3d11va-copy
set FFMPEG_DIR=ffmpeg-9.0.2-essentials_build
rem NUGET_SOURCE: optional mirror if nuget.org is slow/blocked for you, e.g. https://nuget.cdn.azure.cn/v3/index.json  (leave empty for the default)
set NUGET_SOURCE=
rem =======================================================

where dotnet >nul 2>nul
if errorlevel 1 (
  echo [ERROR] .NET SDK not found. Install the .NET 10 SDK from https://dotnet.microsoft.com/download then run build.bat again.
  pause & exit /b 1
)
for /f "delims=" %%v in ('dotnet --version') do set SDKV=%%v
echo Using .NET SDK %SDKV%
echo %SDKV% | findstr /b "10." >nul
if errorlevel 1 (
  echo [ERROR] The player targets net10.0 and needs the .NET 10 SDK, found %SDKV%.
  pause & exit /b 1
)

if exist dist rmdir /s /q dist
mkdir dist

rem a half-downloaded runtime pack ("Central Directory corrupt") from an earlier failed build - this project no longer needs it
if exist "%USERPROFILE%\.nuget\packages\microsoft.netcore.app.runtime.win-x64" rmdir /s /q "%USERPROFILE%\.nuget\packages\microsoft.netcore.app.runtime.win-x64"

echo.
echo ===== [1/3] Player - mpvnet.exe =====
call :restore "src\MpvNet.Windows\MpvNet.Windows.csproj"
if errorlevel 1 ( echo [ERROR] Package restore failed - check your internet connection or set NUGET_SOURCE at the top of build.bat. & pause & exit /b 1 )
dotnet publish "src\MpvNet.Windows\MpvNet.Windows.csproj" -c Release --no-restore -o "dist"
if errorlevel 1 ( echo [ERROR] Player build failed. Copy the errors above and send them to me. & pause & exit /b 1 )

echo.
echo ===== [2/3] Library - AnimeLibrary.exe =====
call :restore "AnimeLibrary\AnimeLibrary.csproj"
if errorlevel 1 ( echo [ERROR] Package restore failed. & pause & exit /b 1 )
dotnet publish "AnimeLibrary\AnimeLibrary.csproj" -c Release --no-restore -o "dist"
if errorlevel 1 ( echo [ERROR] Library build failed. Copy the errors above and send them to me. & pause & exit /b 1 )

echo.
echo ===== [3/3] Config, libmpv, ffmpeg =====
set "STAGE=%~dp0dist\_cfg"
mkdir "%STAGE%"
robocopy "portable_config" "%STAGE%" /E /NFL /NDL /NJH /NJS /NP >nul

set ANIME=0
if exist "mpv-anime-build\mpv.conf" set ANIME=1
if "%ANIME%"=="1" (
  echo Merging mpv-anime-build with the AnimePlayer extras...
  if exist "%STAGE%\input.conf" move /y "%STAGE%\input.conf" "%STAGE%\animeplayer-input.conf" >nul
  robocopy "mpv-anime-build" "%STAGE%" /E /XD .git .github docs screenshots /XF Readme.md CHANGELOG.md FAQ.md AGENTS.md index.html sitemap.xml favicon.svg .gitignore .gitmodules .nojekyll PUT_ANIME_BUILD_HERE.txt /NFL /NDL /NJH /NJS /NP >nul
  powershell -NoProfile -ExecutionPolicy Bypass -File "tools\merge-config.ps1" -Cfg "%STAGE%" -PotWins %POTPLAYER_WINS% -Hwdec "%HWDEC%"
  if errorlevel 1 ( echo [ERROR] Config merge failed. & pause & exit /b 1 )
) else (
  echo [!] mpv-anime-build folder is empty - using the basic built-in config instead.
)

if /i "%CONFIG_MODE%"=="PORTABLE" goto deploy_portable

set "TARGET=%APPDATA%\mpv"
if exist "%TARGET%\mpv.conf" (
  for /f %%t in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set STAMP=%%t
  echo Existing config found - backing it up to %TARGET%.backup-!STAMP!
  robocopy "%TARGET%" "%TARGET%.backup-!STAMP!" /E /NFL /NDL /NJH /NJS /NP >nul
)
if not exist "%TARGET%" mkdir "%TARGET%"
rem never overwrite the user's own settings/data on re-build
for %%f in (overrides.conf anime-settings.json resume.json queue.json watched.log) do (
  if not exist "%TARGET%\%%f" if exist "%STAGE%\%%f" copy /y "%STAGE%\%%f" "%TARGET%\%%f" >nul
)
robocopy "%STAGE%" "%TARGET%" /E /XF overrides.conf anime-settings.json resume.json queue.json watched.log /NFL /NDL /NJH /NJS /NP >nul
echo Config installed to %TARGET%
goto deployed

:deploy_portable
robocopy "%STAGE%" "dist\portable_config" /E /NFL /NDL /NJH /NJS /NP >nul
echo Config placed in dist\portable_config

:deployed
rmdir /s /q "%STAGE%"

rem ---- libmpv (any .dll inside dll\) ----
set HAVE_DLL=0
for /r "dll" %%f in (*.dll) do ( copy /y "%%f" "dist\" >nul & set HAVE_DLL=1 )

rem ---- ffmpeg (searches the folder recursively, so a nested extract also works) ----
set "FF="
set "FP="
for /r "%FFMPEG_DIR%" %%f in (ffmpeg.exe) do if exist "%%f" if not defined FF set "FF=%%f"
for /r "%FFMPEG_DIR%" %%f in (ffprobe.exe) do if exist "%%f" if not defined FP set "FP=%%f"
if defined FF copy /y "!FF!" "dist\" >nul
if defined FP copy /y "!FP!" "dist\" >nul

echo.
set MISSING=0
if "%HAVE_DLL%"=="0" ( echo [!] No libmpv-2.dll found in the dll folder - see dll\PUT_libmpv_HERE.txt & set MISSING=1 )
if not defined FF ( echo [!] ffmpeg.exe not found in %FFMPEG_DIR% - the subtitle sync window needs it, see the PUT_FFMPEG_HERE.txt there & set MISSING=1 )
if "%ANIME%"=="0" ( echo [!] mpv-anime-build folder is empty - see mpv-anime-build\PUT_ANIME_BUILD_HERE.txt & set MISSING=1 )
echo.
echo Done. Output folder: %~dp0dist   - mpvnet.exe and AnimeLibrary.exe
if "%MISSING%"=="1" echo Add the missing files above and run build.bat again.
pause
exit /b 0

:restore
set TRY=0
:restore_try
set /a TRY+=1
echo Restoring packages for %~1 - attempt !TRY! of 4
if defined NUGET_SOURCE ( dotnet restore "%~1" --source "%NUGET_SOURCE%" ) else ( dotnet restore "%~1" )
if not errorlevel 1 exit /b 0
if !TRY! GEQ 4 exit /b 1
echo Restore failed - waiting 5 seconds and retrying...
timeout /t 5 /nobreak >nul
goto restore_try

