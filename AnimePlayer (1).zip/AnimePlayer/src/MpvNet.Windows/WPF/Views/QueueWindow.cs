using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Collections.ObjectModel;

using MpvNet.Windows.Anime;

namespace MpvNet.Windows.WPF.Views;

public class QueueWindow : Window
{
    public static QueueWindow? Instance;
    readonly ObservableCollection<string> _playlist = new();
    readonly ListBox _queueBox = new() { AllowDrop = true, SelectionMode = SelectionMode.Extended };
    readonly ListBox _playlistBox = new() { AllowDrop = true, SelectionMode = SelectionMode.Extended };
    readonly Button _resume = new() { Margin = new Thickness(3), Padding = new Thickness(10, 4, 10, 4), Visibility = Visibility.Collapsed };
    readonly Action<int> _posChanged;
    Point _dragStart;
    object? _dragItem;
    int _dragIdx = -1;
    ListBoxItem? _hot;
    static readonly Brush HotBrush = new SolidColorBrush(Color.FromArgb(150, 124, 92, 255));

    public QueueWindow()
    {
        Title = "Queue & Playlist";
        Width = 720; Height = 540; MinWidth = 480; MinHeight = 320;
        ResizeMode = ResizeMode.CanResize;
        Background = new SolidColorBrush(Color.FromRgb(20, 20, 28));
        Foreground = Brushes.White;
        Topmost = true;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;

        var tabs = new TabControl { Background = Brushes.Transparent, Margin = new Thickness(8) };
        tabs.Items.Add(new TabItem { Header = "Queue (unrelated videos)", Content = BuildQueueTab() });
        tabs.Items.Add(new TabItem { Header = "Playlist (similar videos)", Content = BuildPlaylistTab() });

        // Resume button: only exists when a previous, unfinished session was saved (hidden for first-time videos)
        _resume.Click += (_, _) => ResumeStore.ResumeLastSession();
        var top = new DockPanel { Margin = new Thickness(8, 8, 8, 0) };
        top.Children.Add(_resume);
        var root = new DockPanel();
        DockPanel.SetDock(top, Dock.Top);
        root.Children.Add(top); root.Children.Add(tabs);
        Content = root;

        _queueBox.ItemsSource = QueueStore.Items;
        _playlistBox.ItemsSource = _playlist;
        RefreshResume();
        RefreshPlaylist();

        Instance = this;
        _posChanged = _ => AnimeCore.Ui?.InvokeAsync(RefreshPlaylist);
        Player.PlaylistPosChanged += _posChanged;
        Closed += (_, _) => { Instance = null; Player.PlaylistPosChanged -= _posChanged; QueueStore.Save(); };
    }


    // ---------- drag & drop reordering ----------
    static ListBoxItem? ContainerAt(ListBox lb, object? source) =>
        source is DependencyObject d ? ItemsControl.ContainerFromElement(lb, d) as ListBoxItem : null;

    void SetHot(ListBoxItem? c)
    {
        if (_hot == c) return;
        if (_hot != null) _hot.Background = Brushes.Transparent;
        _hot = c;
        if (_hot != null) _hot.Background = HotBrush;
    }

    /// <summary>Index at which a dropped item should be inserted (before the returned index), from the pointer position.</summary>
    static int InsertIndex(ListBox lb, DragEventArgs e)
    {
        var c = ContainerAt(lb, e.OriginalSource);
        if (c == null) return lb.Items.Count;
        int i = lb.ItemContainerGenerator.IndexFromContainer(c);
        return e.GetPosition(c).Y > c.ActualHeight / 2 ? i + 1 : i;
    }

    void HookDrag(ListBox lb, Action<DragEventArgs, int> dropInternal, string format)
    {
        lb.PreviewMouseLeftButtonDown += (_, e) =>
        {
            _dragStart = e.GetPosition(null);
            var c = ContainerAt(lb, e.OriginalSource);
            _dragItem = c == null ? null : lb.ItemContainerGenerator.ItemFromContainer(c);
            _dragIdx = c == null ? -1 : lb.ItemContainerGenerator.IndexFromContainer(c);
        };
        lb.PreviewMouseMove += (_, e) =>
        {
            if (e.LeftButton != MouseButtonState.Pressed || _dragItem == null) return;
            var d = e.GetPosition(null) - _dragStart;
            if (Math.Abs(d.X) < SystemParameters.MinimumHorizontalDragDistance && Math.Abs(d.Y) < SystemParameters.MinimumVerticalDragDistance) return;
            var item = _dragItem; _dragItem = null;
            DragDrop.DoDragDrop(lb, new DataObject(format, item), DragDropEffects.Move);
            SetHot(null);
        };
        lb.PreviewMouseLeftButtonUp += (_, _) => _dragItem = null;
        lb.DragOver += (_, e) =>
        {
            e.Effects = e.Data.GetDataPresent(format) ? DragDropEffects.Move : e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            SetHot(ContainerAt(lb, e.OriginalSource));
            e.Handled = true;
        };
        lb.DragLeave += (_, _) => SetHot(null);
        lb.Drop += (_, e) =>
        {
            SetHot(null);
            if (e.Data.GetDataPresent(format)) { dropInternal(e, InsertIndex(lb, e)); e.Handled = true; }
        };
    }

    void RefreshResume()
    {
        var s = ResumeStore.LastSession();
        if (s == null) { _resume.Visibility = Visibility.Collapsed; return; }
        _resume.Content = $"↻ Resume last session: {System.IO.Path.GetFileNameWithoutExtension(s.Value.path)} at {AnimeCore.FormatTime(s.Value.entry.Pos)}";
        _resume.Visibility = Visibility.Visible;
    }

    static void StyleList(ListBox lb)
    {
        lb.Background = new SolidColorBrush(Color.FromRgb(30, 30, 42));
        lb.Foreground = Brushes.White;
        lb.BorderBrush = new SolidColorBrush(Color.FromRgb(70, 70, 110));
    }

    static Button Btn(string text, RoutedEventHandler click)
    {
        var b = new Button { Content = text, Margin = new Thickness(3), Padding = new Thickness(10, 4, 10, 4) };
        b.Click += click;
        return b;
    }

    UIElement BuildQueueTab()
    {
        StyleList(_queueBox);
        // files dropped from Explorer are added; dragging items inside the list reorders them
        _queueBox.Drop += (_, e) => { if (e.Data.GetData(DataFormats.FileDrop) is string[] files) QueueStore.AddPaths(files); };
        HookDrag(_queueBox, (e, at) =>
        {
            var dragged = (QueueItem)e.Data.GetData("ap-queue-item")!;
            var moving = _queueBox.SelectedItems.Contains(dragged) ? _queueBox.SelectedItems.Cast<QueueItem>().ToList() : new List<QueueItem> { dragged };
            QueueStore.MoveItems(moving, at);
            _queueBox.SelectedItems.Clear();
            foreach (var m in moving) _queueBox.SelectedItems.Add(m);
        }, "ap-queue-item");
        _queueBox.MouseDoubleClick += (_, _) => PlaySelected();
        _queueBox.KeyDown += (_, e) => { if (e.Key == Key.Delete) QueueStore.Remove(_queueBox.SelectedItems.Cast<QueueItem>()); };

        var sortBox = new ComboBox { Margin = new Thickness(3), Width = 150 };
        foreach (var s in new[] { "Sort: Name (A-Z)", "Name (Z-A)", "Date (newest)", "Date (oldest)", "Size (largest)", "Size (smallest)", "Random" })
            sortBox.Items.Add(s);
        sortBox.SelectedIndex = 0;
        bool init = true;
        sortBox.SelectionChanged += (_, _) => { if (!init) QueueStore.Sort(sortBox.SelectedIndex); };
        init = false;

        var bar = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
        bar.Children.Add(Btn("Add files...", (_, _) => AddFilesDialog()));
        bar.Children.Add(Btn("▶ Play", (_, _) => PlaySelected()));
        bar.Children.Add(Btn("🗑 Delete selected", (_, _) => QueueStore.Remove(_queueBox.SelectedItems.Cast<QueueItem>())));
        bar.Children.Add(Btn("🗑 Delete entire queue", (_, _) =>
        {
            if (QueueStore.Items.Count == 0) return;
            if (MessageBox.Show(this, $"Delete all {QueueStore.Items.Count} items from the queue?", "Delete entire queue",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                QueueStore.Clear();
        }));
        bar.Children.Add(sortBox);

        var dp = new DockPanel();
        DockPanel.SetDock(bar, Dock.Bottom);
        dp.Children.Add(bar);
        dp.Children.Add(_queueBox);
        return dp;
    }

    UIElement BuildPlaylistTab()
    {
        StyleList(_playlistBox);
        _playlistBox.Drop += (_, e) =>
        {
            if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return;
            foreach (var f in files.SelectMany(p => Directory.Exists(p)
                ? (IEnumerable<string>)Directory.EnumerateFiles(p).Where(QueueStore.IsVideo).OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
                : new[] { p }))
                Player.CommandV("loadfile", f, "append-play");
            RefreshPlaylist();
        };
        HookDrag(_playlistBox, (e, at) =>
        {
            int from = _dragIdx;
            if (from < 0 || at == from || at == from + 1) return;
            Player.CommandV("playlist-move", from.ToString(), at.ToString());
            RefreshPlaylist();
            _playlistBox.SelectedIndex = at > from ? at - 1 : at;
        }, "ap-playlist-item");
        _playlistBox.MouseDoubleClick += (_, _) =>
        {
            if (_playlistBox.SelectedIndex >= 0) Player.SetPropertyInt("playlist-pos", _playlistBox.SelectedIndex);
        };
        _playlistBox.KeyDown += (_, e) =>
        {
            if (e.Key != Key.Delete) return;
            foreach (int i in _playlistBox.SelectedItems.Cast<object>().Select(o => _playlistBox.Items.IndexOf(o)).OrderByDescending(x => x))
                Player.CommandV("playlist-remove", i.ToString());
            RefreshPlaylist();
        };

        var bar = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
        bar.Children.Add(Btn("Add files...", (_, _) => AddFilesDialog(toPlaylist: true)));
        bar.Children.Add(Btn("Move up", (_, _) => MovePl(-1)));
        bar.Children.Add(Btn("Move down", (_, _) => MovePl(1)));
        bar.Children.Add(Btn("Shuffle", (_, _) => { Player.Command("playlist-shuffle"); RefreshPlaylist(); }));
        bar.Children.Add(Btn("Clear playlist", (_, _) => { Player.Command("playlist-clear"); RefreshPlaylist(); }));

        var dp = new DockPanel();
        DockPanel.SetDock(bar, Dock.Bottom);
        dp.Children.Add(bar);
        dp.Children.Add(_playlistBox);
        return dp;
    }

    void AddFilesDialog(bool toPlaylist = false)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog { Multiselect = true, Filter = "Video|*.mkv;*.mp4;*.avi;*.webm;*.mov;*.m4v;*.ts;*.flv;*.wmv;*.mpg;*.mpeg|All|*.*" };
        if (dlg.ShowDialog() != true) return;
        if (toPlaylist) { foreach (var f in dlg.FileNames) Player.CommandV("loadfile", f, "append-play"); RefreshPlaylist(); }
        else QueueStore.AddPaths(dlg.FileNames);
    }

    void PlaySelected()
    {
        if (_queueBox.SelectedItem is QueueItem q) Player.CommandV("loadfile", q.Path);
    }

    void RefreshPlaylist()
    {
        _playlist.Clear();
        int n = Player.GetPropertyInt("playlist-count");
        int cur = Player.GetPropertyInt("playlist-pos");
        for (int i = 0; i < n; i++)
        {
            string f = Player.GetPropertyString($"playlist/{i}/filename");
            _playlist.Add((i == cur ? "▶ " : "   ") + System.IO.Path.GetFileName(f));
        }
        RefreshResume();
    }

    void MovePl(int dir)
    {
        int i = _playlistBox.SelectedIndex;
        if (i < 0) return;
        int j = i + dir;
        if (j < 0 || j >= _playlist.Count) return;
        Player.CommandV("playlist-move", i.ToString(), (dir > 0 ? j + 1 : j).ToString());
        RefreshPlaylist();
        _playlistBox.SelectedIndex = j;
    }
}
