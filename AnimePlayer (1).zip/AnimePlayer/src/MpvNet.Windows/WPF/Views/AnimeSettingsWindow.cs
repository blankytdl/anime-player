using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using MpvNet.Windows.Anime;
using static MpvNet.Global;

namespace MpvNet.Windows.WPF.Views;

/// <summary>AnimePlayer settings. Works with both configs: with mpv-anime-build installed the GPU/decoder settings patch its
/// [Platform-Windows-Base] profile (its auto-profiles would override overrides.conf) and the upscaler box drives the build's own
/// anime-mode bindings; without it, overrides.conf and my built-in profiles are used.</summary>
public class AnimeSettingsWindow : Window
{
    readonly bool _anime = AnimeCore.AnimeBuildPresent;

    public AnimeSettingsWindow()
    {
        Title = "AnimePlayer Settings"; Width = 500; Height = 640; Topmost = true;
        Background = new SolidColorBrush(Color.FromRgb(20, 20, 28));
        var sp = new StackPanel { Margin = new Thickness(16) };

        sp.Children.Add(new TextBlock { Text = _anime ? "Config: mpv-anime-build detected" : "Config: built-in basic profiles", Foreground = Brushes.Gray, Margin = new Thickness(0, 0, 0, 8) });

        // ---- middle-click speed (read by the Lua script at startup) ----
        double ffSpeed = 2.5;
        try
        {
            string f = System.IO.Path.Combine(Player.ConfigFolder, "script-opts", "midclick-ff.conf");
            if (File.Exists(f))
            {
                var m = Regex.Match(File.ReadAllText(f), @"speed\s*=\s*([\d.]+)");
                if (m.Success) ffSpeed = double.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
            }
        }
        catch { }
        var ff = (Slider)Row(sp, "Middle-click fast-forward speed", new Slider { Minimum = 1.25, Maximum = 8, Value = Math.Clamp(ffSpeed, 1.25, 8), Width = 200 });

        // ---- GPU / decoder ----
        var gpu = new ComboBox { Width = 220 };
        foreach (var g in new[] { "d3d11 (safe on RX 580)", "vulkan", "opengl" }) gpu.Items.Add(g);
        gpu.SelectedIndex = _anime ? 1 : 0; Row(sp, "GPU API (restart needed)", gpu);
        var hw = new ComboBox { Width = 220 };
        foreach (var g in new[] { "d3d11va-copy", "d3d11va", "auto-safe", "no (software)" }) hw.Items.Add(g);
        hw.SelectedIndex = 0; Row(sp, "Hardware decoding", hw);

        // ---- upscaler: applies immediately ----
        var up = new ComboBox { Width = 220 };
        foreach (var g in _anime
                     ? new[] { "Auto (anime / live detect)", "Force anime shaders", "Force live-action shaders", "Shaders off" }
                     : new[] { "Auto (anime / live detect)", "Anime HD pipeline", "Live-action pipeline", "Lite (low load)" })
            up.Items.Add(g);
        up.SelectedIndex = 0;
        bool ready = false;
        up.SelectionChanged += (_, _) =>
        {
            if (!ready) return;
            string[] cmds = _anime
                ? new[] { "script-binding anime-mode-auto", "script-binding anime-mode-on", "script-binding anime-mode-off", "no-osd change-list glsl-shaders clr \"\"" }
                : new[] { "script-message reapply", "apply-profile anime-hd", "apply-profile live-hd", "apply-profile lite" };
            Player.Command(cmds[up.SelectedIndex]);
        };
        Row(sp, "Real-time upscaler (applies now)", up);
        ready = true;

        // ---- behaviour ----
        var idle = new CheckBox { Content = "Stay open after the last video (needed for queue auto-advance)", Foreground = Brushes.White, IsChecked = true, Margin = new Thickness(0, 6, 0, 2) };
        try { idle.IsChecked = !File.ReadAllText(AnimeCore.ConfigFile("overrides.conf")).Contains("idle=no"); } catch { }
        sp.Children.Add(idle);

        var pin = new CheckBox { Content = "Pin to top (always on top)", Foreground = Brushes.White, Margin = new Thickness(0, 6, 0, 2) };
        pin.IsChecked = Player.GetPropertyString("ontop") == "yes";
        pin.Click += (_, _) => Player.SetPropertyBool("ontop", pin.IsChecked == true);
        sp.Children.Add(pin);

        var quick = new CheckBox { Content = "Show the ☰ quick menu at the player's top-left", Foreground = Brushes.White, IsChecked = AnimeOptions.ShowQuickMenu, Margin = new Thickness(0, 6, 0, 2) };
        sp.Children.Add(quick);

        // ---- cache ----
        var clrExit = new CheckBox { Content = "Delete cache/temp files on exit and at startup", Foreground = Brushes.White, IsChecked = AnimeOptions.ClearCacheOnExit, Margin = new Thickness(0, 10, 0, 2) };
        var clrShader = new CheckBox { Content = "Also delete GPU shader cache (slower first start)", Foreground = Brushes.White, IsChecked = AnimeOptions.ClearShaderCacheOnExit, Margin = new Thickness(0, 4, 0, 2) };
        var clrNow = new Button { Content = "Clear cache now", Padding = new Thickness(12, 4, 12, 4), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 6, 0, 4) };
        clrNow.Click += (_, _) => { int n = CacheCleaner.Clean(clrShader.IsChecked == true); MessageBox.Show($"Cache cleared ({n} items removed)."); };
        sp.Children.Add(clrExit); sp.Children.Add(clrShader); sp.Children.Add(clrNow);

        var save = new Button { Content = "Save", Padding = new Thickness(16, 5, 16, 5), Margin = new Thickness(0, 14, 0, 0), HorizontalAlignment = HorizontalAlignment.Right };
        save.Click += (_, _) =>
        {
            try
            {
                string cf = Player.ConfigFolder;
                Directory.CreateDirectory(System.IO.Path.Combine(cf, "script-opts"));
                File.WriteAllText(System.IO.Path.Combine(cf, "script-opts", "midclick-ff.conf"), "speed=" + ff.Value.ToString("0.00", CultureInfo.InvariantCulture) + "\n");

                string api = gpu.SelectedIndex == 1 ? "vulkan" : gpu.SelectedIndex == 2 ? "opengl" : "d3d11";
                string hwv = hw.SelectedIndex == 3 ? "no" : hw.SelectedItem!.ToString()!;

                var ov = new List<string> { "# written by AnimePlayer Settings", "idle=" + (idle.IsChecked == true ? "yes" : "no"), "hwdec=" + hwv, "vd-lavc-threads=4" };
                if (_anime) PatchPlatformProfile(api, hwv);   // the build's auto-profiles would override overrides.conf
                else ov.Add("gpu-api=" + api);
                File.WriteAllLines(System.IO.Path.Combine(cf, "overrides.conf"), ov);
                Player.SetPropertyString("hwdec", hwv);

                AnimeOptions.ClearCacheOnExit = clrExit.IsChecked == true;
                AnimeOptions.ClearShaderCacheOnExit = clrShader.IsChecked == true;
                AnimeOptions.ShowQuickMenu = quick.IsChecked == true;
                if (AnimeOptions.ShowQuickMenu) QuickMenu.EnsureShown(); else QuickMenu.HideIt();
                AnimeOptions.Save();
                MessageBox.Show("Saved. Decoder applies now; GPU API, idle and middle-click speed apply after a restart.");
            }
            catch (Exception ex) { MessageBox.Show("Could not save: " + ex.Message); }
        };
        sp.Children.Add(save);
        Content = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = sp };
    }

    /// <summary>Rewrites gpu-api / gpu-context / hwdec inside the build's [Platform-Windows-Base] profile (backup: mpv.conf.bak).</summary>
    static void PatchPlatformProfile(string api, string hwdec)
    {
        string f = AnimeCore.ConfigFile("mpv.conf");
        string text = File.ReadAllText(f);
        int a = text.IndexOf("[Platform-Windows-Base]", StringComparison.Ordinal);
        if (a < 0) return;
        int b = text.IndexOf("\n[", a + 5, StringComparison.Ordinal);
        if (b < 0) b = text.Length;
        string block = text[a..b];
        (string gApi, string gCtx) = api switch
        {
            "d3d11" => ("d3d11", "d3d11"),
            "opengl" => ("opengl", "auto"),
            _ => ("vulkan,auto", "winvk,auto")
        };
        block = Regex.Replace(block, @"(?m)^gpu-api=.*$", "gpu-api=" + gApi);
        block = Regex.Replace(block, @"(?m)^gpu-context=.*$", "gpu-context=" + gCtx);
        block = Regex.Replace(block, @"(?m)^hwdec=.*$", "hwdec=" + hwdec);
        string bak = f + ".bak";
        if (!File.Exists(bak)) File.Copy(f, bak);
        AnimeCore.WriteAtomic(f, text[..a] + block + text[b..]);
    }

    static FrameworkElement Row(Panel parent, string label, FrameworkElement ctl)
    {
        var dp = new DockPanel { Margin = new Thickness(0, 6, 0, 6) };
        dp.Children.Add(new TextBlock { Text = label, Foreground = Brushes.White, Width = 240, VerticalAlignment = VerticalAlignment.Center });
        dp.Children.Add(ctl); parent.Children.Add(dp);
        return ctl;
    }
}
