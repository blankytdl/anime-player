using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using static MpvNet.Global;

namespace MpvNet.Windows.WPF.Views;

/// <summary>Visual playback-speed adjuster: slider + presets, always in sync with mpv's speed property.</summary>
public class SpeedWindow : Window
{
    readonly Slider _s = new() { Minimum = 0.25, Maximum = 4, Value = 1, TickFrequency = 0.25, TickPlacement = System.Windows.Controls.Primitives.TickPlacement.BottomRight, Width = 420, Margin = new Thickness(10) };
    readonly TextBlock _t = new() { Foreground = Brushes.White, FontSize = 34, HorizontalAlignment = HorizontalAlignment.Center };
    bool _busy;

    public SpeedWindow()
    {
        Title = "Playback Speed"; SizeToContent = SizeToContent.WidthAndHeight; Topmost = true;
        ResizeMode = ResizeMode.CanMinimize;
        Background = new SolidColorBrush(Color.FromRgb(20, 20, 28));
        var presets = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center };
        foreach (var v in new[] { 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0 })
        {
            var b = new Button { Content = v + "x", Margin = new Thickness(3), Padding = new Thickness(10, 3, 10, 3) };
            b.Click += (_, _) => _s.Value = v;
            presets.Children.Add(b);
        }
        var sp = new StackPanel { Margin = new Thickness(12) };
        sp.Children.Add(_t); sp.Children.Add(_s); sp.Children.Add(presets);
        Content = sp;
        _s.ValueChanged += (_, _) => { if (_busy) return; Player.SetPropertyDouble("speed", Math.Round(_s.Value, 2)); _t.Text = _s.Value.ToString("0.00") + "x"; };
        var poll = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(300) };
        poll.Tick += (_, _) =>
        {
            double v = Player.GetPropertyDouble("speed", false);
            if (v <= 0 || Math.Abs(v - _s.Value) < 0.001) return;
            _busy = true; _s.Value = Math.Clamp(v, 0.25, 4); _t.Text = v.ToString("0.00") + "x"; _busy = false;
        };
        poll.Start();
        Closed += (_, _) => poll.Stop();
    }
}
