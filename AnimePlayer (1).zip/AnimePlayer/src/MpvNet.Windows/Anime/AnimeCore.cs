using System.Collections.ObjectModel;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

using Microsoft.Win32;

namespace MpvNet.Windows.Anime;

/// <summary>Startup/shutdown glue: crash-safe queue, resume positions, queue auto-advance.</summary>
public static class AnimeCore
{
    public static Dispatcher? Ui;
    static System.Threading.Timer? _timer;
    static int _tick;
    static string? _eofHandled;
    static string? _lastPath;
    static bool? _animeBuild;
    static readonly object TickLock = new();

    public static void Init()
    {
        Ui = Dispatcher.CurrentDispatcher;
        AnimeOptions.Load();
        QueueStore.Load();
        ResumeStore.Load();
        System.Threading.Tasks.Task.Run(() => CacheCleaner.Clean(false)); // leftovers from a crash / power-off
        Player.FileLoaded += () =>
        {
            _eofHandled = null;
            _lastPath = Player.GetPropertyString("path");
            ResumeStore.OnFileLoaded();
        };
        // Without keep-open mpv unloads the file at EOF (path becomes empty), so polling eof-reached is not enough: use the end-file event too.
        Player.EndFile += reason =>
        {
            if (reason == MpvNet.Native.LibMpv.mpv_end_file_reason.MPV_END_FILE_REASON_EOF) OnEof(_lastPath);
        };

        // PC shutdown / log-off, normal exit and unhandled crash all flush to disk
        SystemEvents.SessionEnding += (_, _) => Flush();
        AppDomain.CurrentDomain.ProcessExit += (_, _) => Flush();
        AppDomain.CurrentDomain.UnhandledException += (_, _) => Flush();

        _timer = new System.Threading.Timer(_ => Tick(), null, 1500, 500);
        Ui.InvokeAsync(async () =>
        {
            await System.Threading.Tasks.Task.Delay(1500);
            ResumeStore.OfferLastSession();
            if (AnimeOptions.ShowQuickMenu) QuickMenu.EnsureShown();
        });
    }

    static void Tick()
    {
        if (!System.Threading.Monitor.TryEnter(TickLock)) return;
        try
        {
            string path = Player.GetPropertyString("path");
            if (string.IsNullOrEmpty(path)) return;
            _lastPath = path;

            if (Player.GetPropertyString("eof-reached") == "yes")
            {
                OnEof(path);
                return;
            }
            _eofHandled = null;
            if (++_tick % 4 == 0) ResumeStore.Snapshot(); // every ~2 s
        }
        catch { }
        finally { System.Threading.Monitor.Exit(TickLock); }
    }

    /// <summary>A file played to its end (from the end-file event or from eof-reached with keep-open). Runs once per file.</summary>
    static void OnEof(string? path)
    {
        if (string.IsNullOrEmpty(path) || _eofHandled == path) return;
        _eofHandled = path;
        ResumeStore.MarkFinished(path);
        QueueStore.Advance(path);
    }

    /// <summary>True when the mpv-anime-build config is installed (its mpv.conf has the Platform-*-Base profiles).</summary>
    public static bool AnimeBuildPresent
    {
        get
        {
            if (_animeBuild is bool b) return b;
            try { _animeBuild = File.ReadAllText(ConfigFile("mpv.conf")).Contains("[Platform-Windows-Base]"); }
            catch { _animeBuild = false; }
            return _animeBuild.Value;
        }
    }

    public static void Flush()
    {
        try { ResumeStore.Snapshot(); ResumeStore.Save(); QueueStore.Save(); } catch { }
        try { if (AnimeOptions.ClearCacheOnExit) CacheCleaner.Clean(AnimeOptions.ClearShaderCacheOnExit); } catch { }
    }

    public static string FormatTime(double sec)
    {
        var t = TimeSpan.FromSeconds(Math.Max(0, sec));
        return t.TotalHours >= 1 ? t.ToString(@"h\:mm\:ss") : t.ToString(@"m\:ss");
    }

    public static void WriteAtomic(string path, string text)
    {
        string tmp = path + ".tmp";
        File.WriteAllText(tmp, text);
        File.Move(tmp, path, true);
    }

    /// <summary>Handle of the real player window (works with no-border / fullscreen).</summary>
    public static IntPtr MainHandle() => MpvNet.Windows.WinForms.MainForm.Instance?.Handle ?? IntPtr.Zero;

    public static string ConfigFile(string name) => System.IO.Path.Combine(Player.ConfigFolder, name);
}

public class QueueItem
{
    public string Path { get; set; } = "";
    public string Name => System.IO.Path.GetFileName(Path);
    public long Size { get; set; }
    public DateTime Date { get; set; }
    public string SizeText => (Size / 1048576.0).ToString("0.0") + " MB";
    public override string ToString() => $"{Name}   ({SizeText})";
}

/// <summary>Queue = unrelated videos. Every change is written to disk immediately (atomic), so a crash or power cut loses nothing.</summary>
public static class QueueStore
{
    static readonly string[] VideoExt = { ".mkv", ".mp4", ".avi", ".webm", ".mov", ".m4v", ".ts", ".flv", ".wmv", ".mpg", ".mpeg" };
    static readonly object FileLock = new();
    static readonly Random Rng = new();
    public static ObservableCollection<QueueItem> Items { get; } = new();

    public static bool IsVideo(string p) => VideoExt.Contains(System.IO.Path.GetExtension(p).ToLowerInvariant());

    public static void AddPaths(IEnumerable<string> paths)
    {
        foreach (var p in paths)
        {
            IEnumerable<string> list = Directory.Exists(p)
                ? Directory.EnumerateFiles(p, "*", SearchOption.AllDirectories).Where(IsVideo).OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
                : File.Exists(p) && IsVideo(p) ? new[] { p } : Array.Empty<string>();
            foreach (var f in list)
            {
                if (Items.Any(q => q.Path.Equals(f, StringComparison.OrdinalIgnoreCase))) continue;
                var fi = new FileInfo(f);
                Items.Add(new QueueItem { Path = f, Size = fi.Length, Date = fi.LastWriteTime });
            }
        }
        Save();
    }

    public static void Remove(IEnumerable<QueueItem> items) { foreach (var i in items.ToList()) Items.Remove(i); Save(); }
    public static void Clear() { Items.Clear(); Save(); }

    /// <summary>Drag &amp; drop reorder: moves the given items (kept in their current relative order) so they sit before index <paramref name="insertBefore"/> (in the current list).</summary>
    public static void MoveItems(IEnumerable<QueueItem> moving, int insertBefore)
    {
        var set = moving.Where(Items.Contains).OrderBy(i => Items.IndexOf(i)).ToList();
        if (set.Count == 0) return;
        int shift = set.Count(i => Items.IndexOf(i) < insertBefore);
        foreach (var i in set) Items.Remove(i);
        int at = Math.Clamp(insertBefore - shift, 0, Items.Count);
        foreach (var i in set) Items.Insert(at++, i);
        Save();
    }

    public static void Sort(int mode)
    {
        IEnumerable<QueueItem> s = mode switch
        {
            0 => Items.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase),
            1 => Items.OrderByDescending(x => x.Name, StringComparer.OrdinalIgnoreCase),
            2 => Items.OrderByDescending(x => x.Date),
            3 => Items.OrderBy(x => x.Date),
            4 => Items.OrderByDescending(x => x.Size),
            5 => Items.OrderBy(x => x.Size),
            _ => Items.OrderBy(_ => Rng.Next()),
        };
        var list = s.ToList();
        Items.Clear();
        foreach (var i in list) Items.Add(i);
        Save();
    }

    public static void Save()
    {
        try
        {
            lock (FileLock)
                AnimeCore.WriteAtomic(AnimeCore.ConfigFile("queue.json"), JsonSerializer.Serialize(Items.Select(q => q.Path).ToArray()));
        }
        catch { }
    }

    public static void Load()
    {
        try
        {
            string f = AnimeCore.ConfigFile("queue.json");
            if (!File.Exists(f)) return;
            var paths = JsonSerializer.Deserialize<string[]>(File.ReadAllText(f)) ?? Array.Empty<string>();
            Items.Clear();
            foreach (var p in paths)
            {
                if (File.Exists(p)) { var fi = new FileInfo(p); Items.Add(new QueueItem { Path = p, Size = fi.Length, Date = fi.LastWriteTime }); }
                else Items.Add(new QueueItem { Path = p }); // keep entries on unplugged drives
            }
        }
        catch { }
    }

    /// <summary>Called when a file reached its end: continue with the next queue item if mpv's own playlist is exhausted.</summary>
    public static void Advance(string finishedPath)
    {
        int pos = Player.GetPropertyInt("playlist-pos");
        int count = Player.GetPropertyInt("playlist-count");
        if (count > 0 && pos < count - 1) return;
        AnimeCore.Ui?.InvokeAsync(() =>
        {
            var cur = Items.FirstOrDefault(q => q.Path.Equals(finishedPath, StringComparison.OrdinalIgnoreCase));
            if (cur == null) return;
            int idx = Items.IndexOf(cur) + 1;
            if (idx < Items.Count) Player.CommandV("loadfile", Items[idx].Path);
        });
    }
}

public class ResumeEntry { public double Pos { get; set; } public double Dur { get; set; } public long Updated { get; set; } }
public class ResumeData { public string? Last { get; set; } public Dictionary<string, ResumeEntry> Entries { get; set; } = new(); }

/// <summary>Remembers where you stopped. Written every ~2 s + on exit/shutdown, so crashes and power-offs still resume.
/// Nothing is stored (and no Resume button is shown) until a video has actually been watched for a while.</summary>
public static class ResumeStore
{
    static ResumeData _d = new();
    static readonly object L = new();
    static (string path, double pos)? _pending;
    static double _lastSavedPos = -100;
    static string? _lastSavedPath;

    public static void Load()
    {
        try
        {
            string f = AnimeCore.ConfigFile("resume.json");
            if (File.Exists(f))
            {
                var d = JsonSerializer.Deserialize<ResumeData>(File.ReadAllText(f)) ?? new();
                lock (L) { _d = new ResumeData { Last = d.Last, Entries = new(d.Entries, StringComparer.OrdinalIgnoreCase) }; }
            }
        }
        catch { }
    }

    public static void Save()
    {
        try { lock (L) AnimeCore.WriteAtomic(AnimeCore.ConfigFile("resume.json"), JsonSerializer.Serialize(_d)); } catch { }
    }

    static bool Resumable(ResumeEntry e) => e.Pos >= 10 && (e.Dur <= 0 || e.Pos < e.Dur - 20);

    public static ResumeEntry? Get(string path)
    {
        lock (L) return _d.Entries.TryGetValue(path, out var e) && Resumable(e) ? e : null;
    }

    public static (string path, ResumeEntry entry)? LastSession()
    {
        lock (L)
        {
            if (_d.Last != null && _d.Entries.TryGetValue(_d.Last, out var e) && Resumable(e) && File.Exists(_d.Last))
                return (_d.Last, e);
            return null;
        }
    }

    public static void Snapshot()
    {
        string path = Player.GetPropertyString("path");
        if (string.IsNullOrEmpty(path)) return;
        double pos = Player.GetPropertyDouble("time-pos", false);
        double dur = Player.GetPropertyDouble("duration", false);
        if (pos < 10) return; // first seconds: not "watched" yet, keep any older entry so the Resume button still works
        lock (L)
        {
            if (dur > 0 && pos > dur - 20) { _d.Entries.Remove(path); if (_d.Last == path) _d.Last = null; }
            else
            {
                if (path == _lastSavedPath && Math.Abs(pos - _lastSavedPos) < 1) return;
                _d.Entries[path] = new ResumeEntry { Pos = pos, Dur = dur, Updated = DateTimeOffset.UtcNow.ToUnixTimeSeconds() };
                _d.Last = path;
                _lastSavedPath = path; _lastSavedPos = pos;
            }
        }
        Save();
    }

    public static void Forget(string path)
    {
        lock (L) { _d.Entries.Remove(path); if (_d.Last == path) _d.Last = null; }
        Save();
    }

    /// <summary>Drops saved positions of files that no longer exist (deleted / moved).</summary>
    public static int PruneMissing()
    {
        int n = 0;
        lock (L)
        {
            foreach (var k in _d.Entries.Keys.Where(k => !k.Contains("://") && !File.Exists(k)).ToList())
            { _d.Entries.Remove(k); n++; if (_d.Last == k) _d.Last = null; }
        }
        if (n > 0) Save();
        return n;
    }

    public static void MarkFinished(string path)
    {
        lock (L) { _d.Entries.Remove(path); if (_d.Last == path) _d.Last = null; }
        Save();
    }

    public static void OnFileLoaded() => AnimeCore.Ui?.InvokeAsync(async () =>
    {
        string path = Player.GetPropertyString("path");
        if (string.IsNullOrEmpty(path)) return;
        if (_pending is { } p && p.path.Equals(path, StringComparison.OrdinalIgnoreCase))
        {
            _pending = null;
            Seek(p.pos);
            return;
        }
        var e = Get(path);               // null on first-time viewing -> no button
        if (e == null) return;
        // mpv's own save-position-on-quit (enabled by mpv-anime-build) may already have jumped there; only offer the button when it did not
        await System.Threading.Tasks.Task.Delay(1500);
        if (!path.Equals(Player.GetPropertyString("path"), StringComparison.OrdinalIgnoreCase)) return;
        if (Player.GetPropertyDouble("time-pos", false) >= e.Pos - 5) return;
        ShowButton(path, e);
    });

    public static void OfferLastSession()
    {
        if (!string.IsNullOrEmpty(Player.GetPropertyString("path"))) return; // something already playing
        var s = LastSession();
        if (s != null) ShowButton(s.Value.path, s.Value.entry, loadFirst: true);
    }

    public static void ResumeLastSession()
    {
        var s = LastSession();
        if (s == null) return;
        _pending = (s.Value.path, s.Value.entry.Pos);
        Player.CommandV("loadfile", s.Value.path);
    }

    static void ShowButton(string path, ResumeEntry e, bool loadFirst = false) =>
        ResumeHoverMenu.ShowFor(path, e.Pos, loadFirst);

    internal static void StartFromSaved(string path, double pos, bool loadFirst)
    {
        if (loadFirst) { _pending = (path, pos); Player.CommandV("loadfile", path); }
        else Seek(pos);
    }

    internal static void Seek(double pos) =>
        Player.CommandV("seek", pos.ToString("0.###", CultureInfo.InvariantCulture), "absolute");
}

/// <summary>Resume lives in a hover menu: a small translucent "↻" tab on the player's top-right corner that
/// expands when the mouse touches it. Shown only when there is a saved position (never for first-time videos),
/// hides itself when you resume, forget it, switch video, seek past it, or the player loses focus.</summary>
public class ResumeHoverMenu : Window
{
    static ResumeHoverMenu? _cur;
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }

    readonly string _path; readonly double _pos; readonly bool _loadFirst;
    readonly Border _handle, _menu;
    readonly Border _root = new() { Padding = new Thickness(10) };
    readonly DispatcherTimer _track = new() { Interval = TimeSpan.FromMilliseconds(250) };
    readonly DispatcherTimer _collapse = new() { Interval = TimeSpan.FromMilliseconds(450) };

    public static void ShowFor(string path, double pos, bool loadFirst)
    {
        _cur?.Close();
        _cur = new ResumeHoverMenu(path, pos, loadFirst);
        _cur.Show();
    }

    public static void Dismiss() => _cur?.Close();

    ResumeHoverMenu(string path, double pos, bool loadFirst)
    {
        _path = path; _pos = pos; _loadFirst = loadFirst;
        WindowStyle = WindowStyle.None; AllowsTransparency = true; Background = Brushes.Transparent;
        ShowInTaskbar = false; Topmost = true; ShowActivated = false; ResizeMode = ResizeMode.NoResize;
        SizeToContent = SizeToContent.WidthAndHeight;

        var grad = new LinearGradientBrush(Color.FromRgb(124, 92, 255), Color.FromRgb(64, 160, 255), 0);
        _handle = new Border
        {
            CornerRadius = new CornerRadius(16), Background = grad, Opacity = 0.45, Width = 44, Height = 30,
            Child = new TextBlock { Text = "↻", Foreground = Brushes.White, FontSize = 17, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
        };

        string name = System.IO.Path.GetFileNameWithoutExtension(path);
        if (name.Length > 38) name = name[..38] + "…";
        var panel = new StackPanel { Margin = new Thickness(6) };
        panel.Children.Add(new TextBlock { Text = loadFirst ? "Last session" : "Saved position", Foreground = new SolidColorBrush(Color.FromRgb(170, 170, 200)), FontSize = 11, Margin = new Thickness(8, 2, 8, 0) });
        if (loadFirst) panel.Children.Add(new TextBlock { Text = name, Foreground = Brushes.White, FontSize = 12, Margin = new Thickness(8, 0, 8, 4) });
        panel.Children.Add(Item($"▶  Resume at {AnimeCore.FormatTime(pos)}", () => { Close(); ResumeStore.StartFromSaved(_path, _pos, _loadFirst); }, bold: true));
        panel.Children.Add(Item("✕  Forget this position", () => { Close(); ResumeStore.Forget(_path); }));
        _menu = new Border
        {
            CornerRadius = new CornerRadius(12), Background = new SolidColorBrush(Color.FromArgb(235, 26, 26, 40)),
            BorderBrush = grad, BorderThickness = new Thickness(1.5), Child = panel, Visibility = Visibility.Collapsed, MinWidth = 210
        };

        var stack = new Grid();
        stack.Children.Add(_handle); stack.Children.Add(_menu);
        _handle.HorizontalAlignment = HorizontalAlignment.Right; _menu.HorizontalAlignment = HorizontalAlignment.Right;
        _root.Child = stack; _root.Background = Brushes.Transparent;
        Content = _root;
        _root.Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 14, Opacity = 0.5, ShadowDepth = 1 };

        _root.MouseEnter += (_, _) => { _collapse.Stop(); Expand(true); };
        _root.MouseLeave += (_, _) => { _collapse.Stop(); _collapse.Start(); };
        _collapse.Tick += (_, _) => { _collapse.Stop(); Expand(false); };

        _track.Tick += (_, _) => Track();
        _track.Start();
        Closed += (_, _) => { _track.Stop(); _collapse.Stop(); if (_cur == this) _cur = null; };
        Loaded += (_, _) => Place();
    }

    Border Item(string text, Action click, bool bold = false)
    {
        var b = new Border { CornerRadius = new CornerRadius(8), Padding = new Thickness(10, 7, 10, 7), Margin = new Thickness(0, 1, 0, 1), Background = Brushes.Transparent, Cursor = System.Windows.Input.Cursors.Hand,
            Child = new TextBlock { Text = text, Foreground = Brushes.White, FontSize = 14, FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal } };
        b.MouseEnter += (_, _) => b.Background = new SolidColorBrush(Color.FromArgb(110, 124, 92, 255));
        b.MouseLeave += (_, _) => b.Background = Brushes.Transparent;
        b.MouseLeftButtonUp += (_, _) => click();
        return b;
    }

    void Expand(bool open)
    {
        _menu.Visibility = open ? Visibility.Visible : Visibility.Collapsed;
        _handle.Visibility = open ? Visibility.Collapsed : Visibility.Visible;
        Place();
    }

    void Track()
    {
        try
        {
            string path = Player.GetPropertyString("path");
            double t = Player.GetPropertyDouble("time-pos", false);
            bool gone = _loadFirst ? !string.IsNullOrEmpty(path)
                                   : !path.Equals(_path, StringComparison.OrdinalIgnoreCase) || t > _pos + 5;
            if (gone) { Close(); return; }

            var main = AnimeCore.MainHandle();
            var fg = GetForegroundWindow();
            var own = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            bool show = main != IntPtr.Zero && !IsIconic(main) && (fg == main || fg == own);
            if (show && Visibility != Visibility.Visible) Visibility = Visibility.Visible;
            else if (!show && Visibility == Visibility.Visible) Visibility = Visibility.Hidden;
            if (show) Place();
        }
        catch { }
    }

    void Place()
    {
        try
        {
            var h = AnimeCore.MainHandle();
            if (h == IntPtr.Zero || !GetWindowRect(h, out var r)) return;
            var src = PresentationSource.FromVisual(this);
            double k = src?.CompositionTarget?.TransformFromDevice.M11 ?? 1;
            double left = r.R * k - ActualWidth - 8, top = r.T * k + 40;
            if (Math.Abs(Left - left) > 0.5) Left = left;
            if (Math.Abs(Top - top) > 0.5) Top = top;
        }
        catch { }
    }
}

/// <summary>Top-left hover menu for the borderless player: pin to top + all AnimePlayer windows. Works with no-border and in
/// fullscreen, independent of the mpv.net context menu (which UOSC replaces). Only visible while the player has focus.</summary>
public class QuickMenu : Window
{
    static QuickMenu? _cur;
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }

    readonly Border _handle, _menu;
    readonly TextBlock _pinText = new() { Foreground = Brushes.White, FontSize = 14 };
    readonly DispatcherTimer _track = new() { Interval = TimeSpan.FromMilliseconds(250) };
    readonly DispatcherTimer _collapse = new() { Interval = TimeSpan.FromMilliseconds(450) };

    public static void EnsureShown()
    {
        if (_cur != null) return;
        _cur = new QuickMenu();
        _cur.Show();
    }

    public static void HideIt() { _cur?.Close(); _cur = null; }

    QuickMenu()
    {
        WindowStyle = WindowStyle.None; AllowsTransparency = true; Background = Brushes.Transparent;
        ShowInTaskbar = false; Topmost = true; ShowActivated = false; ResizeMode = ResizeMode.NoResize;
        SizeToContent = SizeToContent.WidthAndHeight;

        var grad = new LinearGradientBrush(Color.FromRgb(124, 92, 255), Color.FromRgb(64, 160, 255), 0);
        _handle = new Border
        {
            CornerRadius = new CornerRadius(16), Background = grad, Opacity = 0.35, Width = 44, Height = 30, HorizontalAlignment = HorizontalAlignment.Left,
            Child = new TextBlock { Text = "☰", Foreground = Brushes.White, FontSize = 17, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
        };

        _pinText.Text = "📌  Pin to top";
        var pin = Item(_pinText, () => { Player.SetPropertyBool("ontop", Player.GetPropertyString("ontop") != "yes"); UpdatePin(); });
        var panel = new StackPanel { Margin = new Thickness(6) };
        panel.Children.Add(pin);
        panel.Children.Add(Item("📋  Queue & Playlist", () => Run("show-queue")));
        panel.Children.Add(Item("💬  Subtitle sync", () => Run("show-subsync")));
        panel.Children.Add(Item("⏩  Playback speed", () => Run("show-speed")));
        panel.Children.Add(Item("📚  Library", () => Run("show-library")));
        panel.Children.Add(Item("⚙  Settings", () => Run("show-anime-settings")));
        _menu = new Border
        {
            CornerRadius = new CornerRadius(12), Background = new SolidColorBrush(Color.FromArgb(235, 26, 26, 40)),
            BorderBrush = grad, BorderThickness = new Thickness(1.5), Child = panel, Visibility = Visibility.Collapsed, MinWidth = 200, HorizontalAlignment = HorizontalAlignment.Left
        };

        var grid = new Grid();
        grid.Children.Add(_handle); grid.Children.Add(_menu);
        var root = new Border { Padding = new Thickness(10), Background = Brushes.Transparent, Child = grid, Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 14, Opacity = 0.5, ShadowDepth = 1 } };
        Content = root;

        root.MouseEnter += (_, _) => { _collapse.Stop(); Expand(true); };
        root.MouseLeave += (_, _) => { _collapse.Stop(); _collapse.Start(); };
        _collapse.Tick += (_, _) => { _collapse.Stop(); Expand(false); };
        _track.Tick += (_, _) => Track();
        _track.Start();
        Closed += (_, _) => { _track.Stop(); _collapse.Stop(); if (_cur == this) _cur = null; };
        Loaded += (_, _) => Place();
    }

    static void Run(string cmd) => Player.Command("script-message-to mpvnet " + cmd);

    Border Item(string text, Action click) => Item(new TextBlock { Text = text, Foreground = Brushes.White, FontSize = 14 }, click);

    Border Item(TextBlock tb, Action click)
    {
        var b = new Border { CornerRadius = new CornerRadius(8), Padding = new Thickness(10, 7, 10, 7), Margin = new Thickness(0, 1, 0, 1), Background = Brushes.Transparent, Cursor = System.Windows.Input.Cursors.Hand, Child = tb };
        b.MouseEnter += (_, _) => b.Background = new SolidColorBrush(Color.FromArgb(110, 124, 92, 255));
        b.MouseLeave += (_, _) => b.Background = Brushes.Transparent;
        b.MouseLeftButtonUp += (_, _) => click();
        return b;
    }

    void UpdatePin() => _pinText.Text = (Player.GetPropertyString("ontop") == "yes" ? "✔  " : "📌  ") + (Player.GetPropertyString("ontop") == "yes" ? "Pinned on top (click to unpin)" : "Pin to top");

    void Expand(bool open)
    {
        if (open) UpdatePin();
        _menu.Visibility = open ? Visibility.Visible : Visibility.Collapsed;
        _handle.Visibility = open ? Visibility.Collapsed : Visibility.Visible;
        Place();
    }

    void Track()
    {
        try
        {
            var main = AnimeCore.MainHandle();
            var fg = GetForegroundWindow();
            var own = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            bool show = main != IntPtr.Zero && !IsIconic(main) && (fg == main || fg == own || IsOurWindow(fg));
            if (show && Visibility != Visibility.Visible) Visibility = Visibility.Visible;
            else if (!show && Visibility == Visibility.Visible) Visibility = Visibility.Hidden;
            if (show) Place();
        }
        catch { }
    }

    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);

    static bool IsOurWindow(IntPtr h)
    {
        if (h == IntPtr.Zero) return false;
        GetWindowThreadProcessId(h, out uint pid);
        return pid == (uint)Environment.ProcessId;
    }

    void Place()
    {
        try
        {
            var h = AnimeCore.MainHandle();
            if (h == IntPtr.Zero || !GetWindowRect(h, out var r)) return;
            var src = PresentationSource.FromVisual(this);
            double k = src?.CompositionTarget?.TransformFromDevice.M11 ?? 1;
            double left = r.L * k + 6, top = r.T * k + 48; // below UOSC's top bar
            if (Math.Abs(Left - left) > 0.5) Left = left;
            if (Math.Abs(Top - top) > 0.5) Top = top;
        }
        catch { }
    }
}

public static class AnimeOptions
{
    public static bool ClearCacheOnExit { get; set; } = true;
    public static bool ClearShaderCacheOnExit { get; set; } = false;
    public static bool ShowQuickMenu { get; set; } = true;
    class Data { public bool ClearCacheOnExit { get; set; } = true; public bool ClearShaderCacheOnExit { get; set; } public bool ShowQuickMenu { get; set; } = true; }

    public static void Load()
    {
        try
        {
            string f = AnimeCore.ConfigFile("anime-settings.json");
            if (!File.Exists(f)) return;
            var d = JsonSerializer.Deserialize<Data>(File.ReadAllText(f));
            if (d == null) return;
            ClearCacheOnExit = d.ClearCacheOnExit; ClearShaderCacheOnExit = d.ClearShaderCacheOnExit; ShowQuickMenu = d.ShowQuickMenu;
        }
        catch { }
    }

    public static void Save()
    {
        try { AnimeCore.WriteAtomic(AnimeCore.ConfigFile("anime-settings.json"), JsonSerializer.Serialize(new Data { ClearCacheOnExit = ClearCacheOnExit, ClearShaderCacheOnExit = ClearShaderCacheOnExit, ShowQuickMenu = ShowQuickMenu })); } catch { }
    }
}

/// <summary>Deletes everything the app can leave behind: ffmpeg temp audio/subtitle files from the subtitle syncer,
/// half-written *.tmp files from a crash, resume entries of deleted videos and (optionally) mpv's GPU shader cache.
/// Runs at startup, on exit/shutdown and from Settings -> Clear cache now.</summary>
public static class CacheCleaner
{
    public static int Clean(bool includeShaderCache)
    {
        int n = 0;
        try { foreach (var f in Directory.EnumerateFiles(System.IO.Path.GetTempPath(), "ap_sync*")) n += Del(f); } catch { }
        try { foreach (var f in Directory.EnumerateFiles(Player.ConfigFolder, "*.tmp")) n += Del(f); } catch { }
        try { n += ResumeStore.PruneMissing(); } catch { }
        if (includeShaderCache)
        {
            try
            {
                string dir = AnimeCore.ConfigFile("cache");
                if (Directory.Exists(dir))
                {
                    foreach (var f in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories)) n += Del(f);
                    foreach (var d in Directory.EnumerateDirectories(dir)) { try { Directory.Delete(d, true); } catch { } }
                }
            }
            catch { }
        }
        return n;
    }

    static int Del(string f) { try { File.Delete(f); return 1; } catch { return 0; } }
}
