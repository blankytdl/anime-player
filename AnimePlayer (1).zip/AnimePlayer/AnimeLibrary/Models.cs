using System.IO;
using System.Text.Json;

namespace AnimeLibrary;

public enum Source { AniList, MyAnimeList, IMDb }
public enum Kind { Anime, Movies }

public class LibFolder
{
    public string Path { get; set; } = "";
    public Source Source { get; set; } = Source.AniList;
    public Kind Kind { get; set; } = Kind.Anime;
}

public class Entry
{
    public string FolderPath { get; set; } = "";
    public string RawName { get; set; } = "";
    public string Title { get; set; } = "";
    public string? CoverFile { get; set; }
    public int? MalId { get; set; }
    public int? AniListId { get; set; }
    public string? ImdbId { get; set; }
    public int Episodes { get; set; }       // files found on disk
    public int Watched { get; set; }        // episodes finished
    public bool Matched { get; set; }
    public bool NeedsSync { get; set; }
    public Kind Kind { get; set; }
    public Source Source { get; set; }
}

public class Settings
{
    public List<LibFolder> Folders { get; set; } = new();
    public string MalClientId { get; set; } = "";
    public string? MalAccess { get; set; }
    public string? MalRefresh { get; set; }
    public string OmdbKey { get; set; } = "";
    public string PlayerExe { get; set; } = "mpvnet.exe";
    public string Accent { get; set; } = "#7C5CFF";
    public bool AutoSyncOnline { get; set; } = true;
    public bool DownloadCovers { get; set; } = true;
    public int TileSize { get; set; } = 180;
    public string WatchLog { get; set; } = "";
}

public static class Store
{
    static readonly string Dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AnimeLibrary");
    static string F(string n) => System.IO.Path.Combine(Dir, n);
    static readonly JsonSerializerOptions J = new() { WriteIndented = true };

    public static T Load<T>(string name, T fallback)
    {
        try { return File.Exists(F(name)) ? JsonSerializer.Deserialize<T>(File.ReadAllText(F(name))) ?? fallback : fallback; }
        catch { return fallback; }
    }
    public static void Save<T>(string name, T value)
    {
        Directory.CreateDirectory(Dir);
        File.WriteAllText(F(name), JsonSerializer.Serialize(value, J));
    }
}
