using System.IO;

namespace AnimeLibrary;

public static class Scanner
{
    static readonly string[] Vid = { ".mkv", ".mp4", ".avi", ".webm", ".mov", ".m4v", ".ts", ".wmv" };

    public static async Task<List<Entry>> ScanAsync(Settings s, List<Entry> existing, IProgress<string> log)
    {
        var result = new List<Entry>();
        foreach (var f in s.Folders.Where(f => Directory.Exists(f.Path)))
        {
            foreach (var dir in Directory.EnumerateDirectories(f.Path))
            {
                var files = Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories)
                                     .Where(p => Vid.Contains(System.IO.Path.GetExtension(p).ToLowerInvariant())).ToList();
                if (files.Count == 0) continue;
                var e = existing.FirstOrDefault(x => x.FolderPath.Equals(dir, StringComparison.OrdinalIgnoreCase))
                        ?? new Entry { FolderPath = dir, RawName = System.IO.Path.GetFileName(dir) };
                e.Kind = f.Kind; e.Source = f.Source; e.Episodes = files.Count;
                e.Title = string.IsNullOrEmpty(e.Title) ? NameParser.CleanTitle(e.RawName) : e.Title;
                string cover = System.IO.Path.Combine(dir, "cover.jpg");
                e.CoverFile = File.Exists(cover) ? cover : null;

                if (!e.Matched && Providers.Online())
                {
                    log.Report("Matching: " + e.Title);
                    try
                    {
                        Match? m = f.Source switch
                        {
                            Source.IMDb => await Providers.SearchImdb(e.Title, s.OmdbKey),
                            Source.MyAnimeList => await Providers.SearchJikan(e.Title) ,
                            _ => await Providers.SearchAniList(e.Title)
                        };
                        // AniList gives MAL id too; for MAL source fall back to AniList for missing data
                        m ??= f.Kind == Kind.Anime ? await Providers.SearchAniList(e.Title) : null;
                        if (m != null)
                        {
                            e.Title = m.Title; e.MalId = m.MalId; e.AniListId = m.AniListId; e.ImdbId = m.ImdbId; e.Matched = true;
                            if (s.DownloadCovers && e.CoverFile == null && await Providers.DownloadCover(m.CoverUrl, dir)) e.CoverFile = cover;
                        }
                    }
                    catch (Exception ex) { log.Report("Network error: " + ex.Message); }
                    await Task.Delay(700); // stay under Jikan/AniList rate limits
                }
                result.Add(e);
            }
        }
        return result;
    }

    /// <summary>Reads watched.log written by the player and bumps Watched counts.</summary>
    public static void ApplyWatchLog(Settings s, List<Entry> entries)
    {
        string log = s.WatchLog;
        if (string.IsNullOrEmpty(log) || !File.Exists(log)) return;
        var seen = new Dictionary<Entry, HashSet<int>>();
        foreach (var line in File.ReadLines(log))
        {
            var parts = line.Split('\t');
            if (parts.Length < 2) continue;
            var e = entries.FirstOrDefault(x => parts[1].StartsWith(x.FolderPath, StringComparison.OrdinalIgnoreCase));
            var n = NameParser.EpisodeNumber(parts[1]);
            if (e == null || n == null) continue;
            if (!seen.TryGetValue(e, out var set)) seen[e] = set = new();
            set.Add(n.Value);
        }
        foreach (var (e, set) in seen)
        {
            int w = set.Count == 0 ? 0 : set.Max();
            if (w > e.Watched) { e.Watched = w; e.NeedsSync = true; }
        }
    }
}
