using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AnimeLibrary;

public class MainWindow : Window
{
    readonly Settings _s = Store.Load("settings.json", new Settings());
    List<Entry> _entries = Store.Load("entries.json", new List<Entry>());
    readonly MalClient _mal;
    readonly WrapPanel _grid = new() { Margin = new Thickness(8) };
    readonly TextBox _search = new() { Width = 220, Margin = new Thickness(6), Padding = new Thickness(4) };
    readonly ComboBox _filter = new() { Width = 110, Margin = new Thickness(6) };
    readonly TextBlock _status = new() { Foreground = Brushes.Gray, Margin = new Thickness(8, 4, 8, 4) };
    readonly ListBox _folders = new() { Background = new SolidColorBrush(Color.FromRgb(28, 28, 40)), Foreground = Brushes.White, MinWidth = 260 };
    Brush Accent => (Brush)new BrushConverter().ConvertFromString(_s.Accent)!;

    public MainWindow()
    {
        Title = "Anime Library"; Width = 1180; Height = 760; MinWidth = 720; MinHeight = 480;
        Background = new LinearGradientBrush(Color.FromRgb(16, 16, 26), Color.FromRgb(30, 22, 48), 90);
        _mal = new MalClient(_s);
        if (string.IsNullOrEmpty(_s.WatchLog))
            _s.WatchLog = Path.Combine(PlayerConfigDir(), "watched.log");

        foreach (var f in new[] { "All", "Anime", "Movies", "Unmatched" }) _filter.Items.Add(f);
        _filter.SelectedIndex = 0;
        _filter.SelectionChanged += (_, _) => Render();
        _search.TextChanged += (_, _) => Render();

        var tile = new Slider { Minimum = 110, Maximum = 320, Value = _s.TileSize, Width = 120, VerticalAlignment = VerticalAlignment.Center };
        tile.ValueChanged += (_, _) => { _s.TileSize = (int)tile.Value; Render(); };

        var bar = new WrapPanel { Background = new SolidColorBrush(Color.FromArgb(120, 0, 0, 0)) };
        bar.Children.Add(_search); bar.Children.Add(_filter);
        bar.Children.Add(B("＋ Folder", AddFolder));
        bar.Children.Add(B("⟳ Scan & Match", async () => await ScanAsync()));
        bar.Children.Add(B("MAL Login", async () => Say(await _mal.LoginAsync() ? "MAL connected." : "MAL login failed (set Client ID in Settings).")));
        bar.Children.Add(B("⇅ Sync to MAL", async () => await SyncAsync()));
        bar.Children.Add(B("⚙ Settings", ShowSettings));
        bar.Children.Add(new TextBlock { Text = "Size", Foreground = Brushes.White, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 4, 0) });
        bar.Children.Add(tile);

        var side = new DockPanel { Width = 280, Margin = new Thickness(6) };
        var rm = B("Remove folder", () => { if (_folders.SelectedIndex >= 0) { _s.Folders.RemoveAt(_folders.SelectedIndex); Persist(); RefreshFolders(); } });
        DockPanel.SetDock(rm, Dock.Bottom);
        var srcBox = new ComboBox { Margin = new Thickness(6) };
        foreach (var x in Enum.GetNames<Source>()) srcBox.Items.Add(x);
        srcBox.SelectionChanged += (_, _) => { if (_folders.SelectedIndex >= 0 && srcBox.SelectedIndex >= 0) { _s.Folders[_folders.SelectedIndex].Source = (Source)srcBox.SelectedIndex; Persist(); } };
        _folders.SelectionChanged += (_, _) => { if (_folders.SelectedIndex >= 0) srcBox.SelectedIndex = (int)_s.Folders[_folders.SelectedIndex].Source; };
        var kindBox = new ComboBox { Margin = new Thickness(6) };
        foreach (var x in Enum.GetNames<Kind>()) kindBox.Items.Add(x);
        kindBox.SelectionChanged += (_, _) => { if (_folders.SelectedIndex >= 0 && kindBox.SelectedIndex >= 0) { _s.Folders[_folders.SelectedIndex].Kind = (Kind)kindBox.SelectedIndex; Persist(); } };
        _folders.SelectionChanged += (_, _) => { if (_folders.SelectedIndex >= 0) kindBox.SelectedIndex = (int)_s.Folders[_folders.SelectedIndex].Kind; };
        var opts = new StackPanel();
        opts.Children.Add(new TextBlock { Text = "Metadata source for selected folder", Foreground = Brushes.White, Margin = new Thickness(6, 8, 6, 0) });
        opts.Children.Add(srcBox);
        opts.Children.Add(new TextBlock { Text = "Library type", Foreground = Brushes.White, Margin = new Thickness(6, 4, 6, 0) });
        opts.Children.Add(kindBox);
        DockPanel.SetDock(opts, Dock.Bottom);
        side.Children.Add(rm); side.Children.Add(opts); side.Children.Add(_folders);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _grid };
        var root = new DockPanel();
        DockPanel.SetDock(bar, Dock.Top); DockPanel.SetDock(_status, Dock.Bottom); DockPanel.SetDock(side, Dock.Left);
        root.Children.Add(bar); root.Children.Add(_status); root.Children.Add(side); root.Children.Add(scroll);
        Content = root;

        RefreshFolders(); Scanner.ApplyWatchLog(_s, _entries); Render();
        // auto-sync as soon as the internet comes back
        NetworkChange.NetworkAvailabilityChanged += (_, e) =>
        {
            if (e.IsAvailable && _s.AutoSyncOnline)
                Dispatcher.InvokeAsync(async () => { await ScanAsync(); await SyncAsync(); });
        };
        Loaded += async (_, _) => { if (Providers.Online() && _s.AutoSyncOnline) await SyncAsync(); };
        Closing += (_, _) => Persist();
    }

    static string PlayerConfigDir()
    {
        string portable = Path.Combine(AppContext.BaseDirectory, "portable_config");
        if (Directory.Exists(portable)) return portable;
        string app = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        string mpv = Path.Combine(app, "mpv");
        return Directory.Exists(mpv) ? mpv : Path.Combine(app, "mpv.net");
    }

    Button B(string t, Action a) { var b = new Button { Content = t, Margin = new Thickness(4), Padding = new Thickness(10, 4, 10, 4), Background = Accent, Foreground = Brushes.White, BorderThickness = new Thickness(0) }; b.Click += (_, _) => a(); return b; }
    Button B(string t, Func<Task> a) { var b = new Button { Content = t, Margin = new Thickness(4), Padding = new Thickness(10, 4, 10, 4), Background = Accent, Foreground = Brushes.White, BorderThickness = new Thickness(0) }; b.Click += async (_, _) => await a(); return b; }
    void Say(string m) => _status.Text = m;
    void Persist() { Store.Save("settings.json", _s); Store.Save("entries.json", _entries); }

    void RefreshFolders() { _folders.Items.Clear(); foreach (var f in _s.Folders) _folders.Items.Add($"{f.Path}   [{f.Source}/{f.Kind}]"); }

    void AddFolder()
    {
        var d = new Microsoft.Win32.OpenFolderDialog();
        if (d.ShowDialog() != true) return;
        _s.Folders.Add(new LibFolder { Path = d.FolderName, Kind = Kind.Anime, Source = Source.AniList });
        Persist(); RefreshFolders();
    }

    async Task ScanAsync()
    {
        var p = new Progress<string>(Say);
        _entries = await Scanner.ScanAsync(_s, _entries, p);
        Scanner.ApplyWatchLog(_s, _entries);
        Persist(); Render(); Say($"Scan finished: {_entries.Count} titles ({_entries.Count(e => !e.Matched)} unmatched).");
    }

    async Task SyncAsync()
    {
        if (!Providers.Online()) { Say("Offline: changes are queued and will sync when internet returns."); return; }
        Scanner.ApplyWatchLog(_s, _entries);
        int ok = 0, fail = 0;
        foreach (var e in _entries.Where(e => e.NeedsSync && e.MalId != null && e.Kind == Kind.Anime).ToList())
        {
            if (await _mal.UpdateAsync(e.MalId!.Value, e.Watched, e.Episodes)) { e.NeedsSync = false; ok++; } else fail++;
        }
        Persist(); Render(); Say($"MAL sync: {ok} updated, {fail} failed/queued.");
    }

    void Render()
    {
        _grid.Children.Clear();
        string q = _search.Text.Trim();
        var list = _entries.Where(e => q.Length == 0 || e.Title.Contains(q, StringComparison.OrdinalIgnoreCase)).Where(e => _filter.SelectedIndex switch
        {
            1 => e.Kind == Kind.Anime, 2 => e.Kind == Kind.Movies, 3 => !e.Matched, _ => true
        }).OrderBy(e => e.Title);
        int w = _s.TileSize;
        foreach (var e in list) _grid.Children.Add(MakeTile(e, w));
    }

    UIElement MakeTile(Entry e, int w)
    {
        var img = new Image { Width = w, Height = w * 1.42, Stretch = Stretch.UniformToFill };
        if (e.CoverFile != null && File.Exists(e.CoverFile))
        {
            var bi = new BitmapImage(); bi.BeginInit(); bi.CacheOption = BitmapCacheOption.OnLoad; bi.DecodePixelWidth = w * 2;
            bi.UriSource = new Uri(e.CoverFile); bi.EndInit(); img.Source = bi;
        }
        var prog = new ProgressBar { Height = 5, Maximum = Math.Max(1, e.Episodes), Value = e.Watched, Foreground = Accent, Background = Brushes.Transparent, BorderThickness = new Thickness(0) };
        var sp = new StackPanel();
        sp.Children.Add(new Border { CornerRadius = new CornerRadius(8), ClipToBounds = true, Child = img, Background = Brushes.Black });
        sp.Children.Add(prog);
        sp.Children.Add(new TextBlock { Text = e.Title, Foreground = Brushes.White, TextTrimming = TextTrimming.CharacterEllipsis, Width = w, Margin = new Thickness(0, 4, 0, 0), FontWeight = FontWeights.SemiBold });
        sp.Children.Add(new TextBlock { Text = $"{e.Watched}/{e.Episodes} eps {(e.NeedsSync ? "• pending sync" : "")}{(e.Matched ? "" : " • unmatched")}", Foreground = Brushes.Gray, FontSize = 11 });
        var card = new Border { Margin = new Thickness(8), Padding = new Thickness(6), CornerRadius = new CornerRadius(10), Background = new SolidColorBrush(Color.FromArgb(70, 255, 255, 255)), Child = sp, Cursor = Cursors.Hand };
        card.MouseEnter += (_, _) => card.Background = new SolidColorBrush(Color.FromArgb(120, 124, 92, 255));
        card.MouseLeave += (_, _) => card.Background = new SolidColorBrush(Color.FromArgb(70, 255, 255, 255));
        card.MouseLeftButtonDown += (_, a) => { if (a.ClickCount == 2) Play(e); };
        var menu = new ContextMenu();
        var plus = new MenuItem { Header = "Mark next episode watched" };
        plus.Click += (_, _) => { e.Watched = Math.Min(e.Episodes, e.Watched + 1); e.NeedsSync = true; Persist(); Render(); };
        var rematch = new MenuItem { Header = "Re-match title..." };
        rematch.Click += async (_, _) =>
        {
            var name = Prompt("Search title", e.Title); if (name == null) return;
            e.Title = name; e.Matched = false; await ScanAsync();
        };
        var open = new MenuItem { Header = "Open folder" };
        open.Click += (_, _) => Process.Start("explorer.exe", e.FolderPath);
        menu.Items.Add(plus); menu.Items.Add(rematch); menu.Items.Add(open);
        card.ContextMenu = menu;
        return card;
    }

    void Play(Entry e)
    {
        var files = Directory.EnumerateFiles(e.FolderPath, "*", SearchOption.AllDirectories)
            .Where(f => new[] { ".mkv", ".mp4", ".avi", ".webm", ".mov", ".m4v" }.Contains(Path.GetExtension(f).ToLowerInvariant()))
            .OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToList();
        if (files.Count == 0) return;
        string player = Path.IsPathRooted(_s.PlayerExe) ? _s.PlayerExe : Path.Combine(AppContext.BaseDirectory, _s.PlayerExe);
        if (!File.Exists(player)) { Say("Player not found: " + player); return; }
        var psi = new ProcessStartInfo(player) { UseShellExecute = false };
        // start at the first unwatched episode, queue the rest
        foreach (var f in files.Skip(Math.Min(e.Watched, files.Count - 1))) psi.ArgumentList.Add(f);
        Process.Start(psi);
    }

    string? Prompt(string title, string def)
    {
        var tb = new TextBox { Text = def, Margin = new Thickness(10) };
        var ok = new Button { Content = "OK", Margin = new Thickness(10), IsDefault = true };
        var w = new Window { Title = title, Width = 380, SizeToContent = SizeToContent.Height, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        var sp = new StackPanel(); sp.Children.Add(tb); sp.Children.Add(ok); w.Content = sp;
        ok.Click += (_, _) => w.DialogResult = true;
        return w.ShowDialog() == true ? tb.Text : null;
    }

    void ShowSettings()
    {
        var id = new TextBox { Text = _s.MalClientId, Margin = new Thickness(6) };
        var omdb = new TextBox { Text = _s.OmdbKey, Margin = new Thickness(6) };
        var accent = new TextBox { Text = _s.Accent, Margin = new Thickness(6) };
        var player = new TextBox { Text = _s.PlayerExe, Margin = new Thickness(6) };
        var covers = new CheckBox { Content = "Download cover art into each folder", IsChecked = _s.DownloadCovers, Margin = new Thickness(6) };
        var auto = new CheckBox { Content = "Auto-sync to MAL when internet is available", IsChecked = _s.AutoSyncOnline, Margin = new Thickness(6) };
        var save = new Button { Content = "Save", Margin = new Thickness(6), Padding = new Thickness(12, 4, 12, 4) };
        var w = new Window { Title = "Settings", Width = 480, SizeToContent = SizeToContent.Height, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        var sp = new StackPanel { Margin = new Thickness(8) };
        void L(string t, Control c) { sp.Children.Add(new TextBlock { Text = t, Margin = new Thickness(6, 4, 6, 0) }); sp.Children.Add(c); }
        L("MyAnimeList Client ID (myanimelist.net/apiconfig, redirect http://localhost:8765/cb)", id);
        L("OMDb API key (for IMDb source, free at omdbapi.com)", omdb);
        L("Accent colour (hex)", accent);
        L("Player exe (name next to this app or full path)", player);
        sp.Children.Add(covers); sp.Children.Add(auto); sp.Children.Add(save);
        w.Content = sp;
        save.Click += (_, _) =>
        {
            _s.MalClientId = id.Text.Trim(); _s.OmdbKey = omdb.Text.Trim(); _s.PlayerExe = player.Text.Trim();
            try { new BrushConverter().ConvertFromString(accent.Text); _s.Accent = accent.Text.Trim(); } catch { }
            _s.DownloadCovers = covers.IsChecked == true; _s.AutoSyncOnline = auto.IsChecked == true;
            Persist(); w.Close(); Render();
        };
        w.ShowDialog();
    }
}
