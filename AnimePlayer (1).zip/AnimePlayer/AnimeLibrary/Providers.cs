using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace AnimeLibrary;

public record Match(string Title, string? CoverUrl, int? MalId, int? AniListId, string? ImdbId, int? Episodes);

public static class Providers
{
    public static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(20) };
    static Providers() => Http.DefaultRequestHeaders.UserAgent.ParseAdd("AnimeLibrary/1.0");

    public static async Task<Match?> SearchAniList(string title)
    {
        const string q = "query($s:String){Media(search:$s,type:ANIME){id idMal episodes title{romaji english} coverImage{extraLarge large}}}";
        var body = JsonSerializer.Serialize(new { query = q, variables = new { s = title } });
        using var r = await Http.PostAsync("https://graphql.anilist.co", new StringContent(body, Encoding.UTF8, "application/json"));
        if (!r.IsSuccessStatusCode) return null;
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        if (!doc.RootElement.TryGetProperty("data", out var d) || d.GetProperty("Media").ValueKind != JsonValueKind.Object) return null;
        var m = d.GetProperty("Media");
        var t = m.GetProperty("title");
        string name = t.GetProperty("english").GetString() ?? t.GetProperty("romaji").GetString() ?? title;
        var c = m.GetProperty("coverImage");
        string? cover = c.TryGetProperty("extraLarge", out var x) ? x.GetString() : c.GetProperty("large").GetString();
        return new Match(name, cover,
            m.TryGetProperty("idMal", out var mal) && mal.ValueKind == JsonValueKind.Number ? mal.GetInt32() : null,
            m.GetProperty("id").GetInt32(), null,
            m.TryGetProperty("episodes", out var ep) && ep.ValueKind == JsonValueKind.Number ? ep.GetInt32() : null);
    }

    public static async Task<Match?> SearchJikan(string title)
    {
        using var r = await Http.GetAsync("https://api.jikan.moe/v4/anime?limit=1&q=" + Uri.EscapeDataString(title));
        if (!r.IsSuccessStatusCode) return null;
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        var arr = doc.RootElement.GetProperty("data");
        if (arr.GetArrayLength() == 0) return null;
        var a = arr[0];
        string? cover = a.GetProperty("images").GetProperty("jpg").GetProperty("large_image_url").GetString();
        return new Match(a.GetProperty("title").GetString() ?? title, cover, a.GetProperty("mal_id").GetInt32(), null, null,
            a.TryGetProperty("episodes", out var e) && e.ValueKind == JsonValueKind.Number ? e.GetInt32() : null);
    }

    /// <summary>IMDb has no free public API; this uses OMDb (free key from omdbapi.com) which is keyed by IMDb data.</summary>
    public static async Task<Match?> SearchImdb(string title, string key)
    {
        if (string.IsNullOrWhiteSpace(key)) return null;
        using var r = await Http.GetAsync($"https://www.omdbapi.com/?apikey={key}&t={Uri.EscapeDataString(title)}");
        if (!r.IsSuccessStatusCode) return null;
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        var o = doc.RootElement;
        if (o.TryGetProperty("Response", out var ok) && ok.GetString() != "True") return null;
        string? poster = o.TryGetProperty("Poster", out var p) ? p.GetString() : null;
        if (poster == "N/A") poster = null;
        return new Match(o.GetProperty("Title").GetString() ?? title, poster, null, null, o.GetProperty("imdbID").GetString(), null);
    }

    public static async Task<bool> DownloadCover(string? url, string folder)
    {
        if (string.IsNullOrEmpty(url)) return false;
        try
        {
            var bytes = await Http.GetByteArrayAsync(url);
            await System.IO.File.WriteAllBytesAsync(System.IO.Path.Combine(folder, "cover.jpg"), bytes);
            return true;
        }
        catch { return false; }
    }

    public static bool Online()
    {
        try { return System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable(); } catch { return false; }
    }
}
