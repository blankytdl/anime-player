using System.Text.RegularExpressions;

namespace AnimeLibrary;

public static class NameParser
{
    static readonly Regex Brackets = new(@"[\[\(\{][^\]\)\}]*[\]\)\}]", RegexOptions.Compiled);
    static readonly Regex Junk = new(@"\b(1080p|720p|480p|2160p|4k|bluray|bd|bdrip|web-?dl|webrip|hevc|x26[45]|h\.?26[45]|aac|flac|10bit|8bit|dual[ -]?audio|multi|batch|complete|uncensored|remux|season\s*\d+|s\d{1,2}|part\s*\d+)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    static readonly Regex Ep = new(@"(?:^|[\s_.\-])(?:e|ep|episode)?\s*(\d{1,3})(?:v\d)?(?=[\s_.\-\[(]|$)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    static readonly Regex Year = new(@"\b(19|20)\d{2}\b", RegexOptions.Compiled);

    /// <summary>Folder or file name -> searchable title ("[SubsPlease] Frieren - 05 (1080p).mkv" -> "Frieren").</summary>
    public static string CleanTitle(string name)
    {
        string s = System.IO.Path.GetFileNameWithoutExtension(name);
        s = Brackets.Replace(s, " ");
        s = s.Replace('_', ' ').Replace('.', ' ');
        s = Junk.Replace(s, " ");
        int dash = s.LastIndexOf(" - ", StringComparison.Ordinal);
        if (dash > 0 && Regex.IsMatch(s[(dash + 3)..], @"^\s*\d{1,3}\b")) s = s[..dash];
        s = Year.Replace(s, " ");
        return Regex.Replace(s, @"\s+", " ").Trim(' ', '-');
    }

    public static int? EpisodeNumber(string fileName)
    {
        string s = Brackets.Replace(System.IO.Path.GetFileNameWithoutExtension(fileName), " ");
        s = Junk.Replace(s, " ");
        var m = Ep.Matches(s);
        return m.Count > 0 && int.TryParse(m[^1].Groups[1].Value, out int n) ? n : null;
    }
}
