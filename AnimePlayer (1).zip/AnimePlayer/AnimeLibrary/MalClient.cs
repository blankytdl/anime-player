using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace AnimeLibrary;

/// <summary>MyAnimeList API v2 with OAuth2 PKCE. Create an app at myanimelist.net/apiconfig (type: "other",
/// redirect URL http://localhost:8765/cb) and paste its Client ID into Settings.</summary>
public class MalClient
{
    const string Redirect = "http://localhost:8765/cb";
    readonly Settings _s;
    public MalClient(Settings s) => _s = s;
    public bool LoggedIn => !string.IsNullOrEmpty(_s.MalAccess);

    static string Rand(int n)
    {
        const string c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
        var b = RandomNumberGenerator.GetBytes(n);
        return new string(b.Select(x => c[x % c.Length]).ToArray());
    }

    public async Task<bool> LoginAsync()
    {
        if (string.IsNullOrWhiteSpace(_s.MalClientId)) return false;
        string verifier = Rand(100); // MAL uses "plain" PKCE: challenge == verifier
        string url = "https://myanimelist.net/v1/oauth2/authorize?response_type=code&client_id=" + _s.MalClientId +
                     "&code_challenge=" + verifier + "&code_challenge_method=plain&redirect_uri=" + Uri.EscapeDataString(Redirect);
        using var l = new HttpListener();
        l.Prefixes.Add("http://localhost:8765/");
        l.Start();
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        var ctx = await l.GetContextAsync();
        string? code = ctx.Request.QueryString["code"];
        var msg = Encoding.UTF8.GetBytes("<html><body style='font-family:sans-serif'>Logged in. You can close this tab.</body></html>");
        await ctx.Response.OutputStream.WriteAsync(msg);
        ctx.Response.Close();
        if (code == null) return false;
        return await TokenAsync(new Dictionary<string, string>
        {
            ["client_id"] = _s.MalClientId, ["grant_type"] = "authorization_code",
            ["code"] = code, ["code_verifier"] = verifier, ["redirect_uri"] = Redirect
        });
    }

    async Task<bool> TokenAsync(Dictionary<string, string> form)
    {
        using var r = await Providers.Http.PostAsync("https://myanimelist.net/v1/oauth2/token", new FormUrlEncodedContent(form));
        if (!r.IsSuccessStatusCode) return false;
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        _s.MalAccess = doc.RootElement.GetProperty("access_token").GetString();
        _s.MalRefresh = doc.RootElement.GetProperty("refresh_token").GetString();
        Store.Save("settings.json", _s);
        return true;
    }

    /// <summary>Sets watched episode count + status for one anime. Retries once after refreshing the token.</summary>
    public async Task<bool> UpdateAsync(int malId, int watched, int totalEpisodes)
    {
        if (!LoggedIn) return false;
        for (int attempt = 0; attempt < 2; attempt++)
        {
            string status = totalEpisodes > 0 && watched >= totalEpisodes ? "completed" : "watching";
            var req = new HttpRequestMessage(HttpMethod.Put, $"https://api.myanimelist.net/v2/anime/{malId}/my_list_status")
            {
                Content = new FormUrlEncodedContent(new Dictionary<string, string> { ["status"] = status, ["num_watched_episodes"] = watched.ToString() })
            };
            req.Headers.Authorization = new("Bearer", _s.MalAccess);
            using var r = await Providers.Http.SendAsync(req);
            if (r.IsSuccessStatusCode) return true;
            if (r.StatusCode != HttpStatusCode.Unauthorized || string.IsNullOrEmpty(_s.MalRefresh)) return false;
            if (!await TokenAsync(new() { ["client_id"] = _s.MalClientId, ["grant_type"] = "refresh_token", ["refresh_token"] = _s.MalRefresh! })) return false;
        }
        return false;
    }
}
