-- Logs finished episodes so AnimeLibrary can sync progress to MyAnimeList.
local utils = require("mp.utils")
local function log_path()
    local dir = mp.command_native({"expand-path", "~~/"})
    return dir .. "/watched.log"
end
mp.register_event("end-file", function(e)
    if e.reason ~= "eof" then return end
    local path = mp.get_property("path")
    if not path then return end
    local f = io.open(log_path(), "a")
    if f then f:write(os.time() .. "\t" .. path .. "\n"); f:close() end
end)
