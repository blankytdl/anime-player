-- Hold middle mouse = fast forward. Speed is configurable via script-opts/midclick-ff.conf
local opts = { speed = 2.5 }
require("mp.options").read_options(opts, "midclick-ff")
local saved = 1
-- bound in input.conf: MBTN_MID script-binding midclick-ff/hold
mp.add_key_binding(nil, "hold", function(t)
    if t.event == "down" then
        saved = mp.get_property_number("speed", 1)
        mp.set_property_number("speed", opts.speed)
        mp.osd_message("▶▶ " .. opts.speed .. "x", 0.6)
    elseif t.event == "up" then
        mp.set_property_number("speed", saved)
        mp.osd_message("▶ " .. saved .. "x", 0.6)
    end
end, { complex = true })
