# AnimePlayer + AnimeLibrary (UNTESTED first drop)

Built on your mpv_net-main source. Not compiled by me (no .NET/Windows in my sandbox) - expect a few compile
errors to fix on first build; send me the output and I'll patch them.

## Build
1. Install the **.NET 10 SDK**.
2. Fill the three drop-in folders (each has a PUT_..._HERE.txt):
   - `dll\` - `libmpv-2.dll` (shinchiro mpv-dev x86_64; not the -v3 build, the i5-3470 has no AVX2)
   - `ffmpeg-9.0.2-essentials_build\` - extracted gyan.dev essentials zip (`bin\ffmpeg.exe`), used by Subtitle Sync (F6)
   - `mpv-anime-build\` - extracted contents of Chinna95P/mpv-anime-build (mpv.conf, input.conf, scripts, shaders, script-opts, fonts)
3. Double-click `build.bat`. Output: `dist\mpvnet.exe` + `dist\AnimeLibrary.exe`.

`build.bat` options (top of the file): `CONFIG_MODE=APPDATA` installs the merged config to `%APPDATA%\mpv` exactly like the anime build's readme
(an existing folder is copied to `mpv.backup-<time>` first; your overrides/resume/queue files are never overwritten); `PORTABLE` puts it in `dist\portable_config`.
`POTPLAYER_WINS=1` makes PotPlayer keys beat the anime build's on clashes; clashes are listed in `key-conflicts.txt` in the config folder.
The player reads config from: `portable_config` next to the exe, else `%APPDATA%\mpv` (new), else `%APPDATA%\mpv.net`.
With the anime build present, my own `anime-detect.lua` is removed (the build does its own anime/live detection) and its UOSC UI is used.
Install the build's `Source Sans Pro` font (in `fonts\`) for its stats overlay.
GPU/decoder overrides for RX 580 + i5-3470 live in `overrides.conf` (d3d11va-copy) and load after the anime build's mpv.conf.

## Keys
With the anime build installed its keys win on a clash (see key-conflicts.txt). AnimePlayer additions that never clash:
F2 Queue & Playlist, F3 Subtitle Sync, F4 visual speed, F8 Library, Ctrl+Shift+S Settings, Ctrl+Alt+L = the build's power-saving toggle,
C/X speed +/-0.1 (Shift = 0.5), Alt+G/H sub delay +/-0.5, Ctrl+H sub delay +0.1, Home/End, PgUp/PgDn playlist,
Ctrl+E screenshot, Ctrl+O open files, Ctrl+U open clipboard URL, Space, Esc, Alt+Enter. Hold the middle mouse button = fast-forward.
Known clashes where the anime build wins by default (set POTPLAYER_WINS=1 to flip): Enter, arrows, Up/Down, Ctrl+G, Ctrl+J/K, Alt+Left/Right, M, S, Z, Ctrl+1-4.
The build already has `[` `]` / `{` `}` for subtitle/audio delay.
Without the anime build you get my plain PotPlayer-style config (Space, Enter fullscreen, arrows seek, Ctrl+T pin, F5/F6/F7 windows are replaced by F2-F4).
The anime build keeps: `!` pin to top, `F5/F6` screenshots, `CTRL+g` shaders on/off, `CTRL+p` power mode, `D` anime menu, etc.

## No-border mode (anime build has `no-border` + `fullscreen=yes`)
- Window resize, dragging and pin-to-top are handled by mpv.net itself for borderless windows (edge resize, drag anywhere, `ontop`).
- The ☰ quick menu (top-left, below UOSC's top bar) has Pin to top, Queue, Subtitle sync, Speed, Library, Settings. It works in fullscreen,
  follows the player window, and only shows while the player (or one of its windows) has focus. Toggle it in Settings.
- The Resume tab is top-right. If mpv already jumped to your saved position (the build has `save-position-on-quit=yes`) it stays hidden;
  it appears after a crash / power-off, when mpv's own resume has nothing saved.

## Resume + queue safety
- Position is saved every ~2 s, on exit/shutdown, on Windows log-off/shutdown and on crashes (`portable_config/resume.json`).
- Resume is a hover menu: a small translucent ↻ tab on the player's top-right corner expands when you point at it ("Resume at m:ss" / "Forget this position"). First-time videos show nothing.
- Opening the player with no file offers "Resume <last video>"; the Queue window (F5) also has a Resume last session button.
- Queue is written to `portable_config/queue.json` on every change (atomic write) and reloaded at startup.
- Drag items inside the Queue (multi-select supported) or Playlist tab to reorder; drop files from Explorer to add.
- "Delete entire queue" button (with confirmation) in the Queue tab; Delete key removes selected items.

## Queue behaviour / idle
mpv.net quits when the last video ends (the anime build sets neither `keep-open` nor `idle`), which would stop the queue from advancing.
`overrides.conf` therefore sets `idle=yes` (player stays open, ready for the next queue item or the Resume offer). Untick it in Settings if you prefer quit-at-end.
End-of-file is detected from mpv's end-file event (works with and without keep-open).

## Settings window
With the anime build installed, GPU API / hardware decoding patch the build's `[Platform-Windows-Base]` profile (backup: `mpv.conf.bak`) because its
auto-profiles override anything in overrides.conf; the upscaler box drives the build's own anime-mode bindings (auto / force anime / force live / shaders off).
Without the build it writes overrides.conf and uses my built-in profiles. Decoder and upscaler apply immediately; GPU API, idle and middle-click speed need a restart.

## Cache cleanup
- Subtitle-sync temp files are deleted right after use; leftovers (`ap_sync*` in %TEMP%, `*.tmp` in portable_config) and resume entries of deleted videos are removed at startup and exit/shutdown.
- GPU shader cache lives in `portable_config/cache`; Settings has "also delete shader cache" and "Clear cache now".
- The library app keeps no temp files (covers are saved in your anime folders on purpose).

## Known gaps in this drop
- No true top menu bar: pin-to-top is in the right-click menu and Settings (mpv.net has no menu bar).
- Real-time upscaling = mpv GLSL shaders (Anime4K/FSRCNNX); no AI video models.
- Subtitle syncer reads SRT (embedded ASS is converted by ffmpeg).
- IMDb uses OMDb (needs a free key). MAL needs your own Client ID.
- Library does not stream from IMDb/MAL lists; it matches your folders to them.
